const express = require('express');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '1mb' }));

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: Number(process.env.ALLES_RATE_LIMIT || 20),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Çok hızlı istek gönderildi. Bir dakika sonra tekrar dene.' }
});
app.use('/api', apiLimiter);

const SYSTEM = `Sen ALLES AI'sın. Türkçe başta olmak üzere kullanıcının dilinde doğal, doğru, yararlı ve doğrudan cevap ver. Kendini başka bir markanın asistanı olarak tanıtma. Kod istendiğinde gerçekten çalışan ve mümkün olduğunca eksiksiz kod ver. Görsel çizme isteği /api/image tarafından ele alınır.`;

function safeHistory(v){
  if(!Array.isArray(v)) return [];
  return v.slice(-12).map(m=>({
    role: m?.role === 'assistant' ? 'assistant' : 'user',
    content: String(m?.content || '').slice(0,12000)
  })).filter(m=>m.content.trim());
}

async function fetchJSON(url, opts, timeout=75000){
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), timeout);
  try{
    const r = await fetch(url, { ...opts, signal: ctrl.signal });
    const raw = await r.text();
    let j = {}; try{ j = JSON.parse(raw); }catch{}
    if(!r.ok) throw new Error(j?.error?.message || j?.message || raw || `HTTP ${r.status}`);
    return j;
  } finally { clearTimeout(timer); }
}

function asTranscript(history, text){
  const h = history.map(m => `${m.role === 'assistant' ? 'ALLES AI' : 'Kullanıcı'}: ${m.content}`).join('\n');
  return `${SYSTEM}\n\n${h}${h?'\n':''}Kullanıcı: ${text}\nALLES AI:`;
}

async function askGemini(text, history){
  const key = process.env.GEMINI_API_KEY;
  if(!key) throw new Error('GEMINI_API_KEY yok');
  const model = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
  const contents = history.map(m=>({ role:m.role==='assistant'?'model':'user', parts:[{text:m.content}] }));
  contents.push({role:'user',parts:[{text}]});
  const j = await fetchJSON(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method:'POST',
    headers:{'Content-Type':'application/json','x-goog-api-key':key},
    body:JSON.stringify({
      systemInstruction:{parts:[{text:SYSTEM}]},
      contents,
      generationConfig:{temperature:0.65,maxOutputTokens:8192}
    })
  });
  const answer=(j?.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();
  if(!answer) throw new Error('Gemini boş yanıt döndürdü');
  return {answer,provider:'Gemini',model};
}

function extractOpenAIResponse(j){
  if(typeof j?.output_text === 'string' && j.output_text.trim()) return j.output_text.trim();
  const out=[];
  for(const item of (j?.output||[])) for(const c of (item?.content||[])) if(typeof c?.text==='string') out.push(c.text);
  return out.join('\n').trim();
}

async function askOpenAI(text, history){
  const key=process.env.OPENAI_API_KEY;
  if(!key) throw new Error('OPENAI_API_KEY yok');
  const model=process.env.OPENAI_MODEL || 'gpt-5.6-luna';
  const input=asTranscript(history,text);
  const j=await fetchJSON('https://api.openai.com/v1/responses',{
    method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},
    body:JSON.stringify({model,input,max_output_tokens:8192})
  });
  const answer=extractOpenAIResponse(j);
  if(!answer) throw new Error('OpenAI boş yanıt döndürdü');
  return {answer,provider:'OpenAI',model};
}

async function askAnthropic(text, history){
  const key=process.env.CLAUDE_API_KEY;
  if(!key) throw new Error('CLAUDE_API_KEY yok');
  const model=process.env.CLAUDE_MODEL || 'claude-sonnet-4-6';
  const messages=[...history,{role:'user',content:text}].map(m=>({role:m.role==='assistant'?'assistant':'user',content:m.content}));
  const j=await fetchJSON('https://api.anthropic.com/v1/messages',{
    method:'POST',headers:{'Content-Type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},
    body:JSON.stringify({model,system:SYSTEM,messages,max_tokens:8192})
  });
  const answer=(j?.content||[]).map(x=>x?.text||'').join('').trim();
  if(!answer) throw new Error('Claude boş yanıt döndürdü');
  return {answer,provider:'Claude',model};
}

async function askCompatible({name,key,base,model,text,history,headers={}}){
  if(!key) throw new Error(`${name} anahtarı yok`);
  const messages=[{role:'system',content:SYSTEM},...history,{role:'user',content:text}];
  const j=await fetchJSON(base,{
    method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key,...headers},
    body:JSON.stringify({model,messages,temperature:0.65,max_tokens:8192})
  });
  const answer=String(j?.choices?.[0]?.message?.content||'').trim();
  if(!answer) throw new Error(`${name} boş yanıt döndürdü`);
  return {answer,provider:name,model};
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'ALLES AI'}));

app.post('/api/chat', async (req,res)=>{
  const text=String(req.body?.text||'').trim();
  const history=safeHistory(req.body?.history);
  if(!text) return res.status(400).json({error:'Mesaj boş.'});
  if(text.length>20000) return res.status(413).json({error:'Mesaj çok uzun.'});

  const providers=[
    ()=>askGemini(text,history),
    ()=>askOpenAI(text,history),
    ()=>askAnthropic(text,history),
    ()=>askCompatible({name:'Grok',key:process.env.GROK_API_KEY,base:'https://api.x.ai/v1/chat/completions',model:process.env.GROK_MODEL||'grok-4-fast',text,history}),
    ()=>askCompatible({name:'DeepSeek',key:process.env.DEEPSEEK_API_KEY,base:'https://api.deepseek.com/chat/completions',model:process.env.DEEPSEEK_MODEL||'deepseek-chat',text,history}),
    ()=>askCompatible({name:'Mistral',key:process.env.MISTRAL_API_KEY,base:'https://api.mistral.ai/v1/chat/completions',model:process.env.MISTRAL_MODEL||'mistral-small-latest',text,history}),
    ()=>askCompatible({name:'Perplexity',key:process.env.PERPLEXITY_API_KEY,base:'https://api.perplexity.ai/chat/completions',model:process.env.PERPLEXITY_MODEL||'sonar',text,history}),
    ()=>askCompatible({name:'OpenRouter',key:process.env.OPENROUTER_API_KEY,base:'https://openrouter.ai/api/v1/chat/completions',model:process.env.OPENROUTER_MODEL||'openai/gpt-5.6-luna',text,history,headers:{'HTTP-Referer':process.env.PUBLIC_URL||'https://alles-ai.onrender.com','X-Title':'ALLES AI'}})
  ];
  let last='Sunucuda hiçbir AI anahtarı tanımlı değil.';
  for(const run of providers){
    try{
      const r=await run();
      return res.json(r);
    }catch(e){ last=String(e?.message||e); }
  }
  return res.status(503).json({error:'Bağlı AI sağlayıcıları yanıt veremedi. '+last});
});

app.post('/api/image', async (req,res)=>{
  const prompt=String(req.body?.prompt||'').trim();
  const key=process.env.OPENAI_API_KEY;
  if(!prompt) return res.status(400).json({error:'Görsel açıklaması boş.'});
  if(!key) return res.status(503).json({error:'Sunucuda OPENAI_API_KEY tanımlı değil. Görsel üretimi için bu anahtar gerekli.'});
  const model=process.env.OPENAI_IMAGE_MODEL || 'gpt-image-2';
  const enhanced=`Yüksek kaliteli, ayrıntılı, doğal ışık, güçlü kompozisyon, temiz detaylar. Kullanıcı isteğini sadık biçimde görselleştir: ${prompt}`;
  const variants=[
    {model,prompt:enhanced,size:'1536x1024',quality:'high',n:1},
    {model,prompt:enhanced,size:'1024x1024',quality:'high',n:1},
    {model,prompt:enhanced,size:'1024x1024',n:1}
  ];
  let last='';
  for(const body of variants){
    try{
      const j=await fetchJSON('https://api.openai.com/v1/images/generations',{
        method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify(body)
      },140000);
      const item=j?.data?.[0]||{};
      const imageUrl=item.b64_json?'data:image/png;base64,'+item.b64_json:String(item.url||'');
      if(!imageUrl) throw new Error('Görsel API boş sonuç döndürdü');
      return res.json({imageUrl,provider:`OpenAI · ${model}`,model});
    }catch(e){ last=String(e?.message||e); }
  }
  return res.status(503).json({error:'Görsel üretilemedi. '+last});
});

app.use(express.static(__dirname, { index: 'index.html', extensions:['html'] }));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'index.html')));

const port=Number(process.env.PORT||10000);
app.listen(port,'0.0.0.0',()=>console.log(`ALLES AI running on ${port}`));
