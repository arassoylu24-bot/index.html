ALLES AI - Render Web Service paketi

Dosyalar:
- index.html
- server.js
- package.json

Render ayarları:
Service Type: Web Service
Build Command: npm install
Start Command: npm start
Plan: Free (test/hobi için)

Environment Variables (en az biri metin için):
GEMINI_API_KEY=...
OPENAI_API_KEY=...

Görsel üretmek için OPENAI_API_KEY gerekir.
İsteğe bağlı yedekler:
CLAUDE_API_KEY=...
GROK_API_KEY=...
DEEPSEEK_API_KEY=...
MISTRAL_API_KEY=...
PERPLEXITY_API_KEY=...
OPENROUTER_API_KEY=...

İsteğe bağlı model değişkenleri:
GEMINI_MODEL=gemini-3.8-flash
OPENAI_MODEL=gpt-5.6-luna
OPENAI_IMAGE_MODEL=gpt-image-2

API anahtarlarını GitHub'a veya index.html içine yazma.
